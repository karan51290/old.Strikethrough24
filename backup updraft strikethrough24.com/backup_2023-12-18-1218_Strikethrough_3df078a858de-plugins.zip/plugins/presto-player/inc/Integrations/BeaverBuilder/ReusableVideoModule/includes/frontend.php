<div class="fl-presto-player-video">
    <?php $module->display(); ?>
</div>