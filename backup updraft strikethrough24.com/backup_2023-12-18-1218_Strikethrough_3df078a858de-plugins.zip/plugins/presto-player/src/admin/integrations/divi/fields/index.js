import VideoSelector from "./VideoSelector/VideoSelector";

export default [VideoSelector];
