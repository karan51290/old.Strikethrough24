import PrestoPlayer from "./PrestoPlayer/PrestoPlayer";

export default [PrestoPlayer];
