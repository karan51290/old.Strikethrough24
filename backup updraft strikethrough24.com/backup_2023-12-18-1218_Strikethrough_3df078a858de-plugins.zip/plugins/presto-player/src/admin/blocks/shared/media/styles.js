import styled from "@emotion/styled";

export const Flex = styled.div`
  box-sizing: border-box;
  display: flex;
  width: 100%;
`;
