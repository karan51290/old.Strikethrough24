export default () => {
  return (
    <div>
      <presto-player-skeleton
        style={{ width: "30%", marginBottom: "10px" }}
      ></presto-player-skeleton>
      <presto-player-skeleton
        style={{ height: "2rem", marginBottom: "20px" }}
      ></presto-player-skeleton>
    </div>
  );
};
