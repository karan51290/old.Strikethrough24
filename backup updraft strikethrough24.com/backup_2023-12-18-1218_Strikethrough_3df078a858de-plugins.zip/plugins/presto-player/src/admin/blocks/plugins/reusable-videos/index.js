import render from "./render";

/**
 * Block Name
 */
export const name = "presto-player";

export const options = {
  render,
};
