export const routes = {
  general: {
    path: "general",
  },
  integrations: {
    path: "/integrations",
  },
  performance: {
    path: "/performance",
  },
};
