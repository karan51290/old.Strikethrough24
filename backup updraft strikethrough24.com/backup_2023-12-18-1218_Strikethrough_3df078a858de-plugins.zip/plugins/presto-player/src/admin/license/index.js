import "./license.scss";
