export const routes = {
  dashboard: {
    path: "/",
  },
  video: {
    path: "/video/:id",
  },
  user: {
    path: "/user/:id",
  },
};
