<?php

/**
 * Moved to Webhook integration.
 * Leave it here to avoid Fatal errors during updating plugin.
 * Remove zapier folder after several versions.
 */
class Forminator_Addon_Zapier_Quiz_Hooks extends Forminator_Addon_Quiz_Hooks_Abstract {

}
