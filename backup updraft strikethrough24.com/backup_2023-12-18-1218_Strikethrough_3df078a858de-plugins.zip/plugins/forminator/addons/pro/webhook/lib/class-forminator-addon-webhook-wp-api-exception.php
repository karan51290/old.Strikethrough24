<?php

/**
 * Class Forminator_Addon_Webhook_Wp_Api_Exception
 * Exception holder forwebhook wp api
 *
 *
 */
class Forminator_Addon_Webhook_Wp_Api_Exception extends Forminator_Addon_Webhook_Exception {
}
