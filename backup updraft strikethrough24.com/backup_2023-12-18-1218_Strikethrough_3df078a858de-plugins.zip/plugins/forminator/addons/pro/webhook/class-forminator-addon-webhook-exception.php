<?php

/**
 * Class Forminator_Addon_Webhook_Exception
 * Not Required but encouraged
 */
class Forminator_Addon_Webhook_Exception extends Exception {

}
